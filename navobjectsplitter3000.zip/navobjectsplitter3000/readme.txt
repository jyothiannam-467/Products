Written by Carsten Scholling <cscholling@hotmail.de>

If you find it usefull, use it regulary or simply like to write, please send me
a short e-mail :-)


Author:        Carsten Scholling
Version:       3.0.0.0
E-Mail:        cscholling@hotmail.de
Copyright:     (c)2007-2012 Carsten Scholling

New features:  - Command line version (use "NavObjectSplitterConsole.exe -help")
               - Sorted join (NAV order, not alphabetical)
               - Rewritten from scratch :)


Applies to:    Microsoft Business Solutions Navision,
               Microsoft Dynamics NAV

               "Microsoft Dynamics NAV" and "Navision" are trademarks of the
               Microsoft Corporation.

License:       This software is distributed free of charge. Redistribution free of
               charge including this file is allowed, selling this software is
               forbidden without the prior written permission of the author. Use
               this software at your own risk. There is no guarantee that it works
               as expected on all configurations nor is there any warranty.

Purpose:       An object splitter? Again? Please read about the advantages
               below:

               The purpose of this software is to provide an easy way to prepare
               Dynamics NAV object text files to be used with comparision
               software like "Beyond Compare" or "UltraCompare" and to give the
               user an easy to use interface and a flexible facility to name,
               order and arrange the resulting object files which is an "must have"
               when updating or merging objects.
             
               Naming is done with a naming template which provides the following
               placeholders:
             
                - {id} *
                - {type}, {TYPE}, {Type}
                - {name}, {NAME}, {Name}
                - {date} *
                - {time} *
                - {version}
              
               All placeholders flagged with an asterisk (*) support formatting.
               All placeholders support length limit ({placeholder,4} = length 4)
			   "type" and "name" allow 3 different styles (lowercase, UPPERCASE and Camel-case)
               
			   For example:
             
               "{Type}_{id:000000000}.txt" will result in 
               "Codeunit_000000001.txt" for Codeunit 1.
             
               "{Type}_{id:000000000}_{version}_{date:yyyyMMdd}.txt" results in
               "Form_000000001_NAVW15.00_20070228.txt"
               for Form 1 in Dynamics NAV 5.00.

               "{type,3}{id}.txt" will result in 
               "for50000.txt" for Form 50000.

               "{TYPE,4}{id}.txt" will result in 
               "QUER50000.txt" for Query 50000.

Configuration: A configuration file for english and german is supplied. Additional
               configurations can easily added to the configuration using
               regular expression syntax. If you don't know how to do that, send
               me an e-mail with the error ("Error while parsing...") and the
               included object part.


Have fun!
